# Models
Contains basic models such as the policy and the baseline. Both are
implemented using neural networks.

## Structure
```sh
models/
    baseline.py
    nn_policy.py
    __init.py
    Readme.md
```