from examples.nes_ball_balancer import main
from examples.nes_cartpoleswingup import main
from examples.nes_cartpoleswingup_rr import main
from examples.nes_doublependulum import main
from examples.nes_pendulum import main
from examples.nes_qube import main

from examples.npg_cartpoleswingup import main
from examples.npg_doublependulum import main
from examples.npg_qube import main
from examples.npg_qube_rr import main
