# Trained data
Contains some pre trained example policies which can be loaded and executed.
## Naming schema
The naming of the policy files follows the given schema:
***gymEnvName***\_***horizon***\_***clip***\_***algorithm***.p,
e.g. *CartpoleSwingShort-v0_10000_6.0_NES.p*